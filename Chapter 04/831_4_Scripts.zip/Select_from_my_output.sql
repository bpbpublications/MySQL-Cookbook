select * from my_output;
