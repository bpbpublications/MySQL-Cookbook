SELECT 'This\nIs\nA\nLine\nFeed';
