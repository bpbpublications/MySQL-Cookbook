SELECT * FROM sakila.address where address2 is not null;
