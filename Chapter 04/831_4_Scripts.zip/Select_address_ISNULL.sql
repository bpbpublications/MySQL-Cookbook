SELECT address_id, address2, isnull(address2) FROM sakila.address;

