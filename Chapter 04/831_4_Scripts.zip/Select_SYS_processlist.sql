SELECT * FROM sys.processlist;
