SELECT 'disappearing\ backslash';
