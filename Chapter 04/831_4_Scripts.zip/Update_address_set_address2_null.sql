UPDATE sakila.address SET address2 = NULL where address_id = 5;
