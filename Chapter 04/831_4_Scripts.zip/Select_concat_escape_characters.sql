select concat('\b',address) from sakila.address; 
