SELECT * FROM sys.session;
