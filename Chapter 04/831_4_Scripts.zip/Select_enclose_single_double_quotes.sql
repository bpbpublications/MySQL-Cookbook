SELECT "hello world", "'hello world'", "''hello world''", "hel""lo wor""ld", "\"hello world";
