create table sakila.my_output(output varchar(2048));
