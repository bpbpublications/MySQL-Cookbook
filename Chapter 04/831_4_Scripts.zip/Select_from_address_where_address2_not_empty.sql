SELECT * FROM sakila.address where address2 != '';
