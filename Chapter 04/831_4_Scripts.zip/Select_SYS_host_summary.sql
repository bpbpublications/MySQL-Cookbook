SELECT * FROM sys.host_summary;
