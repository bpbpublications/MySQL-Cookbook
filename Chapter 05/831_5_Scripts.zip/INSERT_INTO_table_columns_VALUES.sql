INSERT INTO customer (active, address_id, create_date, first_name, last_name, store_id)
VALUES (0, 2, sysdate(), 'Elias', 'Negrin', 2); 