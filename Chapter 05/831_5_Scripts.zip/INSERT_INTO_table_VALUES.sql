INSERT INTO customer
VALUES (601, 2, 'Elias', 'Negrin', 'eliasnegrin@yahoo.com', 2, 0, sysdate(), sysdate());