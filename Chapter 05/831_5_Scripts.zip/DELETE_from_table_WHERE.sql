DELETE FROM customer WHERE customer_id > 601;
DELETE FROM customer WHERE last_name = 'Negrin';