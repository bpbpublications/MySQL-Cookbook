CREATE TABLE address_bak AS SELECT * from address;
SELECT * FROM address_bak;