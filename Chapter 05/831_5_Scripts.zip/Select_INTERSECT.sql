SELECT address_id from address
INTERSECT
SELECT address_id from customer;