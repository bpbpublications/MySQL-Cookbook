SELECT city_id, last_update from address
UNION
SELECT city_id, last_update from city;