UPDATE customer
SET first_name = 'Spencer', last_name = 'Depp', last_update = sysdate()
WHERE customer_id = 602;