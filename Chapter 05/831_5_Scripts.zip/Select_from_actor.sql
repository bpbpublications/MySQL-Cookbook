SELECT actor_id, first_name, last_name from actor;
